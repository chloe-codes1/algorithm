# [문제 2] 사탕 나눠주기

# 속도를 위해 popleft() 사용하려고 deque import!
from collections import deque

T = int(input())
for t in range(1, T+1):
    N, M = map(int, input().split())
    # 어린이별 보유하고 있는 사탕 개수 & 사탕 번호 일단 모두 저장
    info = [ deque(map(int, input().split())) for _ in range(N) ]

    # 어린이 수만큼 순회하며,
    for i in range(N):
        # 0번 index의 사탕 개수를 popleft()로 지우고
        info[i].popleft()
        # set() 에 넣어서 중복을 없애기 -> 이 문제에서는 사탕 종류별 개수만 필요하므로..!
        info[i] = set(info[i])

    # 나눠줄 1에서 M번 까지의 사탕 종류가 담긴 배열 kinds
    kinds = [0] + [1]*M # 1부터 시작하므로 0번 index를 0으로 초기화  &  나머지는 종류별로 1개씩 있으므로 1로 초기화
    count =0 # 어린이들이 보유한 사탕종류의 합을 저장할 변수 count

    # 사탕 종류가 어린이보다 작을 경우에는
    if N > M:
        # 앞의 어린이 M명에게만 나눠주므로 M까지 순회
        children = M
    
    # 사탕 종류가 어린이보다 작지 않으면
    else:
        # 어린이 총 명수 만큼 순회
        children = N

    # 사탕을 나눠줄 수 있는 어린이 수 만큼 순회하며, 
    for i in range(children):
        # 1부터 사탕 종류 수인 M까지 순회 (M까지 순회하려면 당연히 M에 1을 더한다..!)
        for j in range(1, M+1):
            # 만약 사탕 종류 j번이 이미 어린이의 손에 있으면,
            if j in info[i]:
                # 넘어가기
                continue
            # 어린이의 손에 없으면,
            else:
                # 나눠줄 사탕 종류들에 아직 남아있으면 (1로 초기화 해놓았으므로 아직 다른 어린이에게 나누어주지 않았을 때에만 아래의 연산을 실행하도록 함~!)
                if kinds[j]:
                    # 어린이에게 나눠주기
                    info[i].add(j) # set() 이므로 .add()
                    # 나눠준 사탕 종류는 이제 없으므로 0으로 초기화
                    kinds[j] = 0
                    # 어린이 한 명당 사탕 한개씩 나누어주므로, 해당 어린이는 이제 하나를 받았으로 break! 넌 끝!
                    break
    
    # 어린이 수 만큼 순회하며
    for i in range(len(info)):
        # 사탕 종류를 세서 전체 count 에 추가하기  ->  info[i] 는 각각 set()으로 중복 없는 사탕 종류가 들어있으므로 len()으로 셀 수 있다! 
        count += len(info[i])
    
    print('#{} {}'.format(t, count))

                
