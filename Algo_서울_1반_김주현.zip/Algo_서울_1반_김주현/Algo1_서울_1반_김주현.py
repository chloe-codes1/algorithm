# [문제 1] 스도쿠 게임

import copy

first = [0,1,2]
second = [3,4,5]
third = [6,7,8]

def sudoku(arr, row, col, val):
    for i in range(9):
        # 가로 검사하기
        if arr[row][i] == val: # 가로 줄에 넣으려는 숫자가 이미 있으면,
            return 0 # 탈락!
    # 세로 검사하기
    for i in range(9):
        if arr[i][col] == val: # 세로 줄에 넣으려는 숫자가 이미 있어도,
            return 0 #탈락!
    
    x = y = 0

    # 입력될 위치가 어느 위치의 3x3 정사각형인지 찾기
    if row in first:
        x = 3
    elif row in second:
        x = 6
    elif row in third:
        x = 9

    if col in first:
        y = 3
    elif col in second:
        y = 6
    elif col in third:
        y = 9

    # 3x3 검사하기
    for r in range(x-3, x): # 3칸이므로 구한 x,y에서 -3을 한다!
        for c in range(y-3, y):
            if arr[r][c] == val: # 3x3안에 넣으려는 숫자가 이미 있으면,
                return 0 # 탈락!

    # 가로, 세로, 3x3 검사를 모두 통과하면 1을 return 하기     
    return 1
     
T = int(input())

for t in range(1, T+1):
    N = int(input())
    # 스도쿠 판 board
    board = [list(map(int, input().split())) for _ in range(9)]
    # 게임 정보가 담길 games
    games = [list(map(int, input().split())) for _ in range(N)]
    # 게임 실행 횟수를 셀 count 변수
    count = 0
    # 이차원 배열 복사하기 (깊은 복사)
    check = copy.deepcopy(board)
    for i in range(N):
        current = games[i]
        # sudoku() 함수가 1을 return 하면 (모든 검사에서 통과하면)
        if sudoku(check, current[0], current[1], current[2]):
            # 게임 실행 횟수 1 증가
            count += 1
        # 검사에서 떨어지면
        else:    
            # 게임을 멈춰랏!
            break

    print('#{} {}'.format(t,count))
        